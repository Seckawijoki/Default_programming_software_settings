#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

final class ${NAME}ModelImpl implements ${NAME}Contract.Model{
   private ${NAME}Contract.Model.DataCallback callback;
   @Override
   public void onViewInitiate(){
   
   }
   @Override
   public void destroy(){
     callback = null;
   }
   @Override
   public void setDataCallback(${NAME}Contract.Model.DataCallback callback){
     this.callback = callback;
   }
 }