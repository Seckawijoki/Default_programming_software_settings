#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

#if (${VISIBILITY} == "PUBLIC")public #end class ${NAME}Adapter extends FragmentPagerAdapter #if (${INTERFACES} != "") implements ${INTERFACES} #end {

  ${NAME}Adapter(FragmentManager fm) {
    super(fm);
  }

  @Override
  public int getCount() {
    return 0;
  }

  @Override
  public Fragment getItem(int position) {
 
    return null;
  }
}