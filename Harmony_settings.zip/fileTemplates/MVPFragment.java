#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class ${NAME}Fragment extends Fragment #if (${INTERFACES} != "")implements ${INTERFACES} #end{
  private ${NAME}Contract.Presenter presenter;
  
  public static ${NAME}Fragment newInstance() {
    Bundle args = new Bundle();
    ${NAME}Fragment fragment = new ${NAME}Fragment();
    fragment.setArguments(args);
    return fragment;
  }
  
  @Nullable
  @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    setHasOptionsMenu(true);
    return inflater.inflate(R.layout.${NAME}_fragment, container, false);
  }
  @Override
  public void onActivityCreated(@Nullable Bundle savedInstanceState) {
    super.onActivityCreated(savedInstanceState);
     presenter = new ${NAME}PresenterImpl()
        .setModel(getActivity())
        .setView(this)
        .initiate();
  }
  
  @Override
  public void onHiddenChanged(boolean hidden) {
    super.onHiddenChanged(hidden);
  }
  
  @Override
  public void onDetach() {
    super.onDetach();
    presenter.destroy();
    presenter = null;
  }
  
}