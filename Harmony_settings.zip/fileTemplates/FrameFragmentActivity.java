
#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

#if (${VISIBILITY} == "PUBLIC")public #end class ${NAME}Activity extends AppCompatActivity #if (${INTERFACES} != "") implements ${INTERFACES} #end {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.${NAME}_activity);

    ${NAME}Fragment fragment = (${NAME}Fragment)
            getSupportFragmentManager().findFragmentById(R.id.layout_${NAME}_fragment);
    if (fragment == null){
      fragment = ${NAME}Fragment.newInstance();
      ActivityUtils.addFragmentToActivity(
              getSupportFragmentManager(), fragment, R.id.layout_${NAME}_fragment
      );
    }
  }
  
  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    return true;
  }
}