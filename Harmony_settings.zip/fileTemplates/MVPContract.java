#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
import android.support.v4.app.Fragment;

interface ${NAME}Contract{
  interface View{
    void onPresenterInitiate();
    void destroy();
    void setActionCallback(ActionCallback callback);
    interface ActionCallback{
    
    }
  }
  interface Model{
    void onViewInitiate();
    void destroy();
    void setDataCallback(DataCallback callback);
    interface DataCallback{
    
    }
  }
  interface Presenter{
    Presenter initiate();
    void destroy();
    Presenter setView(View view);
    Presenter setView(Fragment fragment);
    Presenter setModel(Activity activity);
  }
}
