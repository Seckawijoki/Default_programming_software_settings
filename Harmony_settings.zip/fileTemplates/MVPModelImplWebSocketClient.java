#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

import android.os.Handler;
import android.util.Log;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;

class ${NAME}ModelImpl extends WebSocketClient implements ${NAME}Contract.Model{
   private ${NAME}Contract.Model.DataCallback callback;
   private static final String TAG = "${NAME}ModelImpl";
   private Handler handler = new Handler();
   ${NAME}ModelImpl() throws URISyntaxException {
     super(new URI(ServerPath.WITH_WIFI_CONDITION));
   }
   @Override
   public void initiate(){
     connect();
   }
   @Override
   public void destroy(){
     callback = null;
   }
   @Override
   public void setDataCallback(${NAME}Contract.Model.DataCallback callback){
     this.callback = callback;
   }
   
   @Override
  public void onOpen( ServerHandshake handShakeData ) {
    Log.e( TAG, "onOpen(): " + handShakeData );
  }

  @Override
  public void onMessage( String message ) {
    Log.d( TAG, "onMessage(): message = " + message );
    
  }

  @Override
  public void onClose( int code, String reason, boolean remote ) {
    Log.e( TAG, "onClose(): " + reason );
  }

  @Override
  public void onError( Exception ex ) {
    Log.e( TAG, "onError(): ", ex );
  }
 }