#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")
import android.support.v4.app.Fragment;

final class ${NAME}PresenterImpl implements ${NAME}Contract.Presenter, 
  ${NAME}Contract.View.ActionCallback, 
  ${NAME}Contract.Model.DataCallback{
   private ${NAME}Contract.View view;
   private ${NAME}Contract.Model model;
 
   @Override
   public ${NAME}Contract.Presenter setView(${NAME}Contract.View view){
     this.view = view;
     return this;
   }
   
   @Override
   public ${NAME}Contract.Presenter setView(Fragment fragment){
     this.view = new  ${NAME}ViewImpl(fragment);
     return this;
   }
   

   @Override
   public ${NAME}Contract.Presenter setModel(Activity activity){
     this.model = new  ${NAME}ModelImpl();
     return this;
   }
   
   @Override
   public ${NAME}Contract.Presenter initiate(){
     view.setActionCallback(this);
     model.setDataCallback(this);
     view.onPresenterInitiate();
     model.onViewInitiate();
     return this;
   }
   
   @Override
   public void destroy(){
     view.destroy();
     model.destroy();
   }
 }