
#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

#if (${VISIBILITY} == "PUBLIC")public #end class ${NAME}Activity extends AppCompatActivity #if (${INTERFACES} != "") implements ${INTERFACES} #end {
  private ${NAME}Contract.Presenter presenter;
  private ${NAME}Fragment fragment;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.${NAME}_activity);

    fragment = (${NAME}Fragment)
            getSupportFragmentManager().findFragmentById(R.id.layout_${NAME}_fragment);
    if (fragment == null){
      fragment = ${NAME}Fragment.newInstance();
      ActivityUtils.addFragmentToActivity(
              getSupportFragmentManager(), fragment, R.id.layout_${NAME}_fragment
      );
    }
    presenter = new ${NAME}PresenterImpl()
        .setModel(this)
        .setView(fragment)
        .initiate();
  }
}