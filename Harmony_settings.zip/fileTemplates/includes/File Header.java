/**
 * Created by Seckawijoki on ${DATE} at ${TIME} under Windows-10 Professional.
 */
