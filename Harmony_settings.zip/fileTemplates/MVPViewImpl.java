#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import android.support.v4.app.Fragment;
import android.view.View;
#if (${IMPORT_BLOCK} != "")${IMPORT_BLOCK}
#end
#parse("File Header.java")

final class ${NAME}ViewImpl implements ${NAME}Contract.View{
   private Activity activity;
   private View view;
   private Fragment fragment;
   private ${NAME}Contract.View.ActionCallback callback;
   @Override
   public void onPresenterInitiate(){
   
   }
   @Override
   public void destroy(){
     activity = null;
     fragment = null;
     callback = null;
   }
   @Override
   public void setActionCallback(${NAME}Contract.View.ActionCallback callback){
     this.callback = callback;
   }
   private ${NAME}ViewImpl(){}
   ${NAME}ViewImpl(Activity activity){
     this.activity = activity;
   }
   ${NAME}ViewImpl(Fragment fragment){
     this.fragment = fragment;
     view = fragment.getView();
     activity = (AppCompatActivity) fragment.getActivity();
   }
 }